package net.nexormc.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import net.nexormc.client.module.ModuleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Nametags modulu: 3. sahis kamerada kendi isim etiketini de gosterir
 * (vanilla yalnizca baskalarininkini gosterir).
 */
@Mixin(LivingEntityRenderer.class)
public abstract class NametagMixin {

    @Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true, require = 0)
    private void nexor$showOwnTag(LivingEntity entity, double distanceSq, CallbackInfoReturnable<Boolean> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (ModuleManager.NAMETAGS.enabled
                && entity == mc.player
                && !mc.options.getCameraType().isFirstPerson()) {
            cir.setReturnValue(true);
        }
    }
}
