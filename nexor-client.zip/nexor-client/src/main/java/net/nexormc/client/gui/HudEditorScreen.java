package net.nexormc.client.gui;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.nexormc.client.module.Module;
import net.nexormc.client.module.ModuleManager;

import java.util.ArrayList;
import java.util.List;

/**
 * "Nexor Settings" ekrani = HUD editoru.
 *
 *   - Altta: her modul icin ac/kapa butonu (+ ayari olanlar icin ayar butonu, + otomatik baglanti).
 *   - Ustte: acik HUD modulleri gercek konumlarinda, cerceveli gorunur.
 *       * Sol tikla tutup SURUKLE  -> tasi
 *       * Fare TEKERLEGI           -> boyutlandir (0.5x - 3x)
 *   - ESC veya Bitti: ayarlari kaydeder ve geldigi ekrana doner.
 *
 * parent null ise (oyun icinden tusla acildiysa) kapaninca oyuna doner.
 */
public class HudEditorScreen extends Screen {

    private static final int BTN_W = 118;
    private static final int BTN_H = 20;
    private static final int GAP = 4;
    private static final int COLUMNS = 3;

    private final Screen parent;
    private Module dragging;
    private double dragOffX;
    private double dragOffY;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("Nexor Settings"));
        this.parent = parent;
    }

    // ---------------------------------------------------------------------- arayuz kurulumu

    @Override
    protected void init() {
        // Butonlari topla: once ac/kapa, sonra ayar butonlari, sonra otomatik baglanti, sonra Bitti
        List<Button> buttons = new ArrayList<>();

        for (Module m : ModuleManager.ALL) {
            buttons.add(Button.builder(onOff(m.name, m.enabled), b -> {
                m.enabled = !m.enabled;
                b.setMessage(onOff(m.name, m.enabled));
            }).size(BTN_W, BTN_H).build());
        }
        for (Module m : ModuleManager.ALL) {
            if (m.settingText() != null) {
                buttons.add(Button.builder(Component.literal(m.settingText()), b -> {
                    m.cycleSetting();
                    b.setMessage(Component.literal(m.settingText()));
                }).size(BTN_W, BTN_H).build());
            }
        }
        buttons.add(Button.builder(onOff("Oto Baglan", ModuleManager.autoConnect), b -> {
            ModuleManager.autoConnect = !ModuleManager.autoConnect;
            b.setMessage(onOff("Oto Baglan", ModuleManager.autoConnect));
        }).size(BTN_W, BTN_H).build());
        buttons.add(Button.builder(Component.literal("Bitti"), b -> onClose())
                .size(BTN_W, BTN_H).build());

        // Alt ortaya izgara olarak yerlestir
        int rows = (buttons.size() + COLUMNS - 1) / COLUMNS;
        int gridW = COLUMNS * BTN_W + (COLUMNS - 1) * GAP;
        int left = (width - gridW) / 2;
        int top = height - 10 - rows * (BTN_H + GAP) + GAP;
        for (int i = 0; i < buttons.size(); i++) {
            Button b = buttons.get(i);
            b.setX(left + (i % COLUMNS) * (BTN_W + GAP));
            b.setY(top + (i / COLUMNS) * (BTN_H + GAP));
            addRenderableWidget(b);
        }
    }

    private static Component onOff(String name, boolean on) {
        return Component.literal(name + ": ")
                .append(Component.literal(on ? "ACIK" : "KAPALI")
                        .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    // ---------------------------------------------------------------------------- cizim

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta); // arka plan + butonlar

        g.drawCenteredString(font, "Nexor Settings", width / 2, 8, 0xFF55FF55);
        g.drawCenteredString(font, "Surukle: tasi  |  Fare tekerlegi: boyut  |  ESC: kaydet ve cik",
                width / 2, 20, 0xFFAAAAAA);

        for (Module m : ModuleManager.ALL) {
            if (!m.hud || !m.enabled) {
                continue;
            }
            m.renderHud(g, minecraft);
            // Cerceve: surukleniyorsa/uzerindeyse parlak
            int x1 = (int) m.x;
            int y1 = (int) m.y;
            int x2 = (int) (m.x + m.width(minecraft) * m.scale);
            int y2 = (int) (m.y + m.height(minecraft) * m.scale);
            boolean hot = m == dragging || m.contains(minecraft, mouseX, mouseY);
            int c = hot ? 0xFF55FF55 : 0x88FFFFFF;
            g.fill(x1 - 1, y1 - 1, x2 + 1, y1, c);
            g.fill(x1 - 1, y2, x2 + 1, y2 + 1, c);
            g.fill(x1 - 1, y1, x1, y2, c);
            g.fill(x2, y1, x2 + 1, y2, c);
        }
    }

    // ---------------------------------------------------------------------------- girdi
    // Minecraft 1.21.9+ fare olaylari MouseButtonEvent nesnesiyle gelir.

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true; // bir butona tiklandi
        }
        if (event.button() == 0) {
            // Ustte cizilen (listede sonda olan) once yakalansin
            for (int i = ModuleManager.ALL.size() - 1; i >= 0; i--) {
                Module m = ModuleManager.ALL.get(i);
                if (m.hud && m.enabled && m.contains(minecraft, event.x(), event.y())) {
                    dragging = m;
                    dragOffX = event.x() - m.x;
                    dragOffY = event.y() - m.y;
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging != null) {
            float maxX = width - dragging.width(minecraft) * dragging.scale;
            float maxY = height - dragging.height(minecraft) * dragging.scale;
            dragging.x = (float) Math.max(0, Math.min(maxX, event.x() - dragOffX));
            dragging.y = (float) Math.max(0, Math.min(maxY, event.y() - dragOffY));
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            ModuleManager.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        for (int i = ModuleManager.ALL.size() - 1; i >= 0; i--) {
            Module m = ModuleManager.ALL.get(i);
            if (m.hud && m.enabled && m.contains(minecraft, mx, my)) {
                m.scale = Math.max(0.5f, Math.min(3f, m.scale + (float) scrollY * 0.1f));
                return true;
            }
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public void onClose() {
        ModuleManager.save();
        minecraft.setScreen(parent); // parent null ise oyuna doner
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
