package net.nexormc.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.nexormc.client.module.ModuleManager;

/**
 * Otomatik sunucu baglantisi.
 *
 * Calisma sekli:
 *   - Oyun acilip ana menu (TitleScreen) ilk kez gelince, ayar aciksa sunucuya baglanir.
 *   - Ana menude SHIFT basili tutulursa atlanir (menuye girmek istersen).
 *   - Oyundan sunucudan cikinca ana menuye donersen tekrar baglanmaz (oturum basina 1 kez).
 *   - /nexor connect komutu istedigin zaman elle baglanir.
 *
 * Not: NexorMC launcher'i zaten "--quickPlayMultiplayer" ile baglaniyor. Ikisi birden
 * calisirsa launcher'inki once davranir ve bu sinif ana menuyu hic gormez. Sadece
 * mod tarafini kullanmak istersen launcher'dan o argumani kaldir.
 */
public final class AutoConnect {

    /** Hedef sunucu. (Kullanici mesajinda "marthos", oncekilerde "marthost" yazilmisti; dogrusunu burada duzelt.) */
    public static final String SERVER_IP = "nexormc.marthost.net";
    public static final String SERVER_NAME = "NexorMC";

    private static boolean triedThisSession;

    private AutoConnect() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((mc, screen, width, height) -> {
            if (!(screen instanceof TitleScreen)) {
                return;
            }
            if (triedThisSession || !ModuleManager.autoConnect || Screen.hasShiftDown()) {
                return;
            }
            triedThisSession = true;
            // Ekran kurulumu bitsin, sonra baglan (init icinde ekran degistirmek sorun cikarir).
            mc.execute(() -> connect(mc, screen));
        });
    }

    /** Sunucuya baglan. parent=null ise mevcut/ana ekrandan donulur. */
    public static void connect(Minecraft mc, Screen parent) {
        Screen back = parent != null ? parent : (mc.screen != null ? mc.screen : new TitleScreen());
        ServerData data = new ServerData(SERVER_NAME, SERVER_IP, ServerData.Type.OTHER);
        ConnectScreen.startConnecting(back, mc, ServerAddress.parseString(SERVER_IP), data, false, null);
    }
}
