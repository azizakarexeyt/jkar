package net.nexormc.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** Yazi satirlari gosteren HUD modulleri icin ortak taban (FPS, XYZ, Ping, Server IP, Pack listesi). */
public abstract class TextModule extends Module {

    private static final int PAD_X = 5;
    private static final int PAD_Y = 4;
    private static final int LINE_H = 10;

    protected TextModule(String id, String name, boolean enabledByDefault, float x, float y) {
        super(id, name, true, enabledByDefault, x, y);
    }

    /** Gosterilecek satirlar (her kare cagrilir, hafif tut). */
    protected abstract List<String> lines(Minecraft mc);

    @Override
    public int width(Minecraft mc) {
        int max = 0;
        for (String line : lines(mc)) {
            max = Math.max(max, mc.font.width(line));
        }
        return max + PAD_X * 2;
    }

    @Override
    public int height(Minecraft mc) {
        return lines(mc).size() * LINE_H + PAD_Y * 2 - 2;
    }

    @Override
    protected void drawContent(GuiGraphics g, Minecraft mc) {
        List<String> lines = lines(mc);
        background(g, width(mc), height(mc));
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(mc.font, lines.get(i), PAD_X, PAD_Y + i * LINE_H, 0xFFFFFFFF, true);
        }
    }
}
