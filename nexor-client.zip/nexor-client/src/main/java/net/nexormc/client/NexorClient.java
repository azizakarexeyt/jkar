package net.nexormc.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.nexormc.client.gui.HudEditorScreen;
import net.nexormc.client.module.ModuleManager;
import net.nexormc.client.module.Modules;

/**
 * Nexor Client ana giris noktasi.
 *
 * Sorumluluklari (hepsi burada baglanir, asil is ilgili siniflarda yapilir):
 *   - ModuleManager: modullerin yuklenmesi / kaydedilmesi / tick'i
 *   - HUD cizimi (Fabric HudElementRegistry)
 *   - Tus atamasi (HUD editoru acma)
 *   - AutoConnect ve CustomGuiPause (ESC menusu)
 *   - /nexor komutu
 */
public class NexorClient implements ClientModInitializer {

    public static final String MOD_ID = "nexormc";

    /**
     * HUD editorunu acan varsayilan tus.
     * NOT: Sol Shift Minecraft'ta "egilme" tusudur; her egildiginde menu acilirdi.
     * Bu yuzden varsayilan SAG SHIFT. Sol Shift istersen KEY_LSHIFT yap ve
     * oyundaki "Egilme" tusunu baska tusa ata.
     */
    private static final int DEFAULT_KEY = InputConstants.KEY_RSHIFT;

    private static KeyMapping openEditorKey;
    /** /nexor settings komutu sohbeti kapatir; ekrani bir sonraki tick'te aciyoruz. */
    private static volatile boolean openEditorPending;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    public static void requestOpenEditor() {
        openEditorPending = true;
    }

    @Override
    public void onInitializeClient() {
        // 1) Modulleri kaydet ve nexormc.json'dan ayarlari oku
        ModuleManager.init();

        // 2) Tus atamasi (kategori ayarlar > tuslar menusunde "Nexor" olarak gorunur)
        KeyMapping.Category category = KeyMapping.Category.register(id("nexor"));
        openEditorKey = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.nexormc.open_editor", InputConstants.Type.KEYSYM, DEFAULT_KEY, category));

        // 3) Her tick: modul tick'leri (Fullbright vb.) + tus kontrolu
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ModuleManager.tick(mc);
            boolean pressed = false;
            while (openEditorKey.consumeClick()) {
                pressed = true;
            }
            if ((pressed || openEditorPending) && mc.player != null && mc.screen == null) {
                openEditorPending = false;
                mc.setScreen(new HudEditorScreen(null));
            } else if (openEditorPending && mc.screen == null) {
                openEditorPending = false;
            }
        });

        // 4) HUD: sohbetin hemen oncesine ciz (Fabric z-sirasini kendisi ayarlar)
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, id("hud"), (graphics, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.screen instanceof HudEditorScreen) {
                return; // editor acikken modulleri kendisi cizer
            }
            ModuleManager.renderHud(graphics, mc);
        });

        // 5) Crosshair: vanilla'yi sarmala. Modul aciksa bizimkini ciz, degilse orijinali birak.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (graphics, delta) -> {
            Modules.CrosshairModule c = ModuleManager.CROSSHAIR;
            if (c.enabled) {
                c.draw(graphics);
            } else {
                original.render(graphics, delta);
            }
        });

        // 6) Otomatik baglanti + ESC menusu
        AutoConnect.register();
        CustomGuiPause.register();

        // 7) /nexor connect | /nexor settings
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("nexor")
                        .then(ClientCommandManager.literal("connect").executes(ctx -> {
                            AutoConnect.connect(Minecraft.getInstance(), null);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("settings").executes(ctx -> {
                            requestOpenEditor();
                            return 1;
                        }))));
    }
}
