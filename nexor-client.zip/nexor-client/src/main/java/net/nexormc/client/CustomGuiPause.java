package net.nexormc.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.Identifier;
import net.nexormc.client.gui.HudEditorScreen;

import java.util.ArrayList;
import java.util.List;

/**
 * ESC (duraklatma) menusu ozellestirmesi. PauseScreen'i degistirmiyoruz, Fabric ekran
 * olaylariyla uzerine ekleme yapiyoruz (diger modlarla cakismamak icin):
 *
 *   1) Arka plan seffaf    -> ScreenBackgroundMixin (blur'u iptal edip hafif karartma cizer)
 *   2) Ustte Nexormc logosu -> afterRender olayinda texture cizilir
 *   3) "Nexor Settings"     -> "Mods" butonunun hemen ustune eklenir, asagidakiler 24px kayar
 *
 * Logo dosyasi: src/main/resources/assets/nexormc/textures/gui/logo.png
 * Arka plani seffaf PNG olmali ve boyutu LOGO_W x LOGO_H piksel olmali.
 */
public final class CustomGuiPause {

    private static final Identifier LOGO = NexorClient.id("textures/gui/logo.png");
    private static final int LOGO_W = 128;
    private static final int LOGO_H = 64;
    /** Logonun ekranin ustunden uzakligi. "Game Menu" yazisi ile cakisirsa artir/azalt. */
    private static final int LOGO_TOP = 2;

    private static final int BUTTON_STEP = 24; // buton yuksekligi 20 + bosluk 4

    private CustomGuiPause() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((mc, screen, width, height) -> {
            if (!(screen instanceof PauseScreen)) {
                return;
            }
            addNexorButton(mc, screen);

            ScreenEvents.afterRender(screen).register((s, graphics, mouseX, mouseY, tickDelta) ->
                    drawLogo(graphics, s.width));
        });
    }

    /** Logoyu ekranin ust ortasina cizer. */
    private static void drawLogo(GuiGraphics g, int screenWidth) {
        int x = (screenWidth - LOGO_W) / 2;
        // blit(pipeline, texture, x, y, u, v, genislik, yukseklik, texGenislik, texYukseklik)
        g.blit(RenderPipelines.GUI_TEXTURED, LOGO, x, LOGO_TOP, 0f, 0f, LOGO_W, LOGO_H, LOGO_W, LOGO_H);
    }

    private static void addNexorButton(net.minecraft.client.Minecraft mc, net.minecraft.client.gui.screens.Screen screen) {
        List<AbstractWidget> widgets = Screens.getButtons(screen);

        AbstractWidget modsButton = null;
        for (AbstractWidget w : widgets) {
            if (isModsButton(w)) {
                modsButton = w;
                break;
            }
        }

        int x;
        int y;
        int w;
        if (modsButton != null) {
            x = modsButton.getX();
            y = modsButton.getY();
            w = modsButton.getWidth();
            // Mods butonu ve altindakileri 24px asagi it
            for (AbstractWidget other : new ArrayList<>(widgets)) {
                if (other.getY() >= y) {
                    other.setY(other.getY() + BUTTON_STEP);
                }
            }
        } else {
            // Mod Menu yoksa: en alttaki butonun altina koy
            AbstractWidget lowest = null;
            for (AbstractWidget other : widgets) {
                if (lowest == null || other.getY() > lowest.getY()) {
                    lowest = other;
                }
            }
            if (lowest == null) {
                return;
            }
            x = lowest.getX();
            y = lowest.getY() + BUTTON_STEP;
            w = lowest.getWidth();
        }

        Button nexor = Button.builder(Component.literal("Nexor Settings"),
                        b -> mc.setScreen(new HudEditorScreen(screen)))
                .bounds(x, y, w, 20)
                .build();
        widgets.add(nexor);
    }

    /** Mod Menu'nun "Mods" butonu: ceviri anahtari "modmenu.*" ya da yazi "Mods" ile baslar. */
    private static boolean isModsButton(AbstractWidget w) {
        Component msg = w.getMessage();
        if (msg.getContents() instanceof TranslatableContents tc && tc.getKey().startsWith("modmenu.")) {
            return true;
        }
        String s = msg.getString();
        return s.equals("Mods") || s.startsWith("Mods (");
    }
}
