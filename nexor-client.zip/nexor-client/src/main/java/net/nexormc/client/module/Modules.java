package net.nexormc.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Yerlesik modullerin hepsi. Her biri kucuk ve bagimsiz; yeni modul eklemek icin
 * buraya bir sinif yazip ModuleManager.init()'e eklemek yeterli.
 */
public final class Modules {

    private Modules() {}

    // ======================================================================= HUD modulleri

    /** FPS sayaci. */
    public static final class FpsModule extends TextModule {
        public FpsModule() {
            super("fps", "FPS", true, 6, 6);
        }

        @Override
        protected List<String> lines(Minecraft mc) {
            return List.of("FPS: " + mc.getFps());
        }
    }

    /** XYZ koordinatlari. */
    public static final class CoordsModule extends TextModule {
        public CoordsModule() {
            super("coords", "Koordinatlar", true, 6, 22);
        }

        @Override
        protected List<String> lines(Minecraft mc) {
            Player p = mc.player;
            if (p == null) {
                return List.of("XYZ: -");
            }
            return List.of(String.format("XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ()));
        }
    }

    /** Ping (ms). Tek oyuncuda 0 gosterir. */
    public static final class PingModule extends TextModule {
        public PingModule() {
            super("ping", "Ping", true, 6, 38);
        }

        @Override
        protected List<String> lines(Minecraft mc) {
            int ping = 0;
            if (mc.player != null && mc.getConnection() != null) {
                PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) {
                    ping = info.getLatency();
                }
            }
            return List.of("Ping: " + ping + " ms");
        }
    }

    /** Bagli oldugun sunucunun IP'si. */
    public static final class ServerIpModule extends TextModule {
        public ServerIpModule() {
            super("serverip", "Server IP", true, 6, 54);
        }

        @Override
        protected List<String> lines(Minecraft mc) {
            ServerData sd = mc.getCurrentServer();
            return List.of(sd != null ? sd.ip : "Tek oyunculu");
        }
    }

    /** Yuklu (secili) kaynak paketlerini listeler. Vanilla/mod icindeki zorunlu paketleri gizler. */
    public static final class PackDisplayModule extends TextModule {
        public PackDisplayModule() {
            super("packs", "Kaynak Paketleri", false, 6, 150);
        }

        @Override
        protected List<String> lines(Minecraft mc) {
            List<String> out = new ArrayList<>();
            out.add("Kaynak paketleri:");
            for (Pack pack : mc.getResourcePackRepository().getSelectedPacks()) {
                if (!pack.isRequired()) {
                    out.add("- " + pack.getTitle().getString());
                }
            }
            if (out.size() == 1) {
                out.add("(yok)");
            }
            return out;
        }
    }

    /** Keystrokes: W A S D + bosluk, basili tus vurgulanir. */
    public static final class KeystrokesModule extends Module {
        private static final int K = 22; // tus boyutu
        private static final int GAP = 2;

        public KeystrokesModule() {
            super("keystrokes", "Keystrokes", true, true, 6, 76);
        }

        @Override
        public int width(Minecraft mc) {
            return K * 3 + GAP * 2;
        }

        @Override
        public int height(Minecraft mc) {
            return K * 2 + GAP + GAP + 14;
        }

        @Override
        protected void drawContent(GuiGraphics g, Minecraft mc) {
            var o = mc.options;
            key(g, mc, K + GAP, 0, K, K, "W", o.keyUp.isDown());
            key(g, mc, 0, K + GAP, K, K, "A", o.keyLeft.isDown());
            key(g, mc, K + GAP, K + GAP, K, K, "S", o.keyDown.isDown());
            key(g, mc, (K + GAP) * 2, K + GAP, K, K, "D", o.keyRight.isDown());
            key(g, mc, 0, (K + GAP) * 2, width(mc), 14, "SPACE", o.keyJump.isDown());
        }

        private static void key(GuiGraphics g, Minecraft mc, int x, int y, int w, int h, String label, boolean down) {
            g.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x66000000);
            int tx = x + (w - mc.font.width(label)) / 2;
            int ty = y + (h - 8) / 2;
            g.drawString(mc.font, label, tx, ty, down ? 0xFF000000 : 0xFFFFFFFF, false);
        }
    }

    /** Armor Status: 4 parca zirh + kalan dayaniklilik. */
    public static final class ArmorModule extends Module {
        private static final EquipmentSlot[] SLOTS = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

        public ArmorModule() {
            super("armor", "Armor Status", true, true, 6, 150 + 70);
        }

        @Override
        public int width(Minecraft mc) {
            return 56;
        }

        @Override
        public int height(Minecraft mc) {
            return SLOTS.length * 18;
        }

        @Override
        protected void drawContent(GuiGraphics g, Minecraft mc) {
            if (mc.player == null) {
                return;
            }
            for (int i = 0; i < SLOTS.length; i++) {
                ItemStack stack = mc.player.getItemBySlot(SLOTS[i]);
                int y = i * 18;
                g.renderItem(stack, 0, y);
                g.renderItemDecorations(mc.font, stack, 0, y);
                if (!stack.isEmpty() && stack.isDamageableItem()) {
                    int left = stack.getMaxDamage() - stack.getDamageValue();
                    g.drawString(mc.font, String.valueOf(left), 20, y + 5, 0xFFFFFFFF, true);
                }
            }
        }
    }

    // ================================================================== Ozellik modulleri

    /** Crosshair degistirici. setting = stil. Cizim NexorClient'taki HUD sarmalayicisindan gelir. */
    public static final class CrosshairModule extends Module {
        private static final String[] STYLES = {"Nokta", "Artı", "Kare", "Büyük Artı"};
        private static final int COLOR = 0xFF55FF55; // Nexor yesili

        public CrosshairModule() {
            super("crosshair", "Crosshair", false, false, 0, 0);
        }

        @Override
        public String settingText() {
            return "Crosshair: " + STYLES[Math.floorMod(setting, STYLES.length)];
        }

        @Override
        public void cycleSetting() {
            setting = (setting + 1) % STYLES.length;
        }

        public void draw(GuiGraphics g) {
            int cx = g.guiWidth() / 2;
            int cy = g.guiHeight() / 2;
            switch (Math.floorMod(setting, STYLES.length)) {
                case 0 -> g.fill(cx - 1, cy - 1, cx + 1, cy + 1, COLOR);
                case 1 -> plus(g, cx, cy, 2, 5);
                case 2 -> {
                    g.fill(cx - 5, cy - 5, cx + 5, cy - 4, COLOR);
                    g.fill(cx - 5, cy + 4, cx + 5, cy + 5, COLOR);
                    g.fill(cx - 5, cy - 4, cx - 4, cy + 4, COLOR);
                    g.fill(cx + 4, cy - 4, cx + 5, cy + 4, COLOR);
                }
                default -> plus(g, cx, cy, 3, 9);
            }
        }

        /** inner: merkezden bosluk, outer: kol uzunlugu. */
        private static void plus(GuiGraphics g, int cx, int cy, int inner, int outer) {
            g.fill(cx - outer, cy, cx - inner, cy + 1, COLOR);
            g.fill(cx + inner, cy, cx + outer, cy + 1, COLOR);
            g.fill(cx, cy - outer, cx + 1, cy - inner, COLOR);
            g.fill(cx, cy + inner, cx + 1, cy + outer, COLOR);
        }
    }

    /**
     * Fullbright: istemci tarafinda sonsuz Gece Gorusu efekti uygular.
     * Sunucu bunu bilmez; sadece senin ekraninda gorunur. Kapatinca efekti geri alir.
     * (Bazi anti-hile sistemleri istemci tarafi fullbright'i yasaklayabilir.)
     */
    public static final class FullbrightModule extends Module {
        private boolean applied;

        public FullbrightModule() {
            super("fullbright", "Fullbright", false, false, 0, 0);
        }

        @Override
        public void tick(Minecraft mc) {
            Player p = mc.player;
            if (p == null) {
                applied = false;
                return;
            }
            if (enabled) {
                MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
                // 200 tick altinda gece gorusu titrer; erken yenile
                if (cur == null || cur.getDuration() < 400) {
                    p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1000, 0, false, false, false));
                    applied = true;
                }
            } else if (applied) {
                p.removeEffect(MobEffects.NIGHT_VISION);
                applied = false;
            }
        }
    }

    /**
     * Nametags: kendi ismini 3. sahis kamerada gosterir.
     * Asil is NametagMixin'de; bu modul sadece ac/kapa bayragidir.
     */
    public static final class NametagsModule extends Module {
        public NametagsModule() {
            super("nametags", "Nametags", false, true, 0, 0);
        }
    }
}
