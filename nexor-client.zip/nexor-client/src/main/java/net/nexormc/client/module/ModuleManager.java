package net.nexormc.client.module;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Modullerin merkezi. Kayit, tick, HUD cizimi ve ayarlarin diske yazilmasi burada.
 *
 * Ayar dosyasi: .minecraft/.../config/nexormc.json
 * {
 *   "autoConnect": true,
 *   "modules": { "fps": {"enabled":true,"x":6,"y":6,"scale":1.0,"setting":0}, ... }
 * }
 */
public final class ModuleManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("nexormc.json");

    /** Siralama editordeki buton siralamasidir. */
    public static final List<Module> ALL = new ArrayList<>();

    // Sik kullanilanlara dogrudan erisim
    public static final Modules.FpsModule FPS = new Modules.FpsModule();
    public static final Modules.CoordsModule COORDS = new Modules.CoordsModule();
    public static final Modules.PingModule PING = new Modules.PingModule();
    public static final Modules.KeystrokesModule KEYSTROKES = new Modules.KeystrokesModule();
    public static final Modules.ArmorModule ARMOR = new Modules.ArmorModule();
    public static final Modules.ServerIpModule SERVER_IP = new Modules.ServerIpModule();
    public static final Modules.PackDisplayModule PACKS = new Modules.PackDisplayModule();
    public static final Modules.CrosshairModule CROSSHAIR = new Modules.CrosshairModule();
    public static final Modules.FullbrightModule FULLBRIGHT = new Modules.FullbrightModule();
    public static final Modules.NametagsModule NAMETAGS = new Modules.NametagsModule();

    /** Ana menude otomatik sunucuya baglan. */
    public static boolean autoConnect = true;

    private ModuleManager() {}

    public static void init() {
        ALL.clear();
        ALL.add(KEYSTROKES);
        ALL.add(FPS);
        ALL.add(COORDS);
        ALL.add(PING);
        ALL.add(ARMOR);
        ALL.add(SERVER_IP);
        ALL.add(PACKS);
        ALL.add(CROSSHAIR);
        ALL.add(FULLBRIGHT);
        ALL.add(NAMETAGS);
        load();
    }

    public static void tick(Minecraft mc) {
        for (Module m : ALL) {
            m.tick(mc);
        }
    }

    /** Oyun ici HUD: acik olan tum HUD modullerini cizer. */
    public static void renderHud(GuiGraphics g, Minecraft mc) {
        for (Module m : ALL) {
            m.renderHud(g, mc);
        }
    }

    // ------------------------------------------------------------------ kaydet / yukle

    /** Diskteki ayarin sekli. */
    private static final class Saved {
        boolean autoConnect = true;
        Map<String, Entry> modules = new HashMap<>();
    }

    private static final class Entry {
        boolean enabled;
        float x;
        float y;
        float scale = 1f;
        int setting;
    }

    public static void save() {
        Saved s = new Saved();
        s.autoConnect = autoConnect;
        for (Module m : ALL) {
            Entry e = new Entry();
            e.enabled = m.enabled;
            e.x = m.x;
            e.y = m.y;
            e.scale = m.scale;
            e.setting = m.setting;
            s.modules.put(m.id, e);
        }
        try {
            Files.writeString(FILE, GSON.toJson(s), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            System.err.println("[Nexor] Ayarlar kaydedilemedi: " + ex);
        }
    }

    private static void load() {
        if (!Files.exists(FILE)) {
            return; // ilk calistirma: varsayilanlar
        }
        try {
            Saved s = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), Saved.class);
            if (s == null) {
                return;
            }
            autoConnect = s.autoConnect;
            if (s.modules == null) {
                return;
            }
            for (Module m : ALL) {
                Entry e = s.modules.get(m.id);
                if (e == null) {
                    continue;
                }
                m.enabled = e.enabled;
                m.x = e.x;
                m.y = e.y;
                m.scale = Math.max(0.5f, Math.min(3f, e.scale));
                m.setting = e.setting;
            }
        } catch (Exception ex) {
            System.err.println("[Nexor] Ayar dosyasi okunamadi, varsayilanlar kullaniliyor: " + ex);
        }
    }
}
