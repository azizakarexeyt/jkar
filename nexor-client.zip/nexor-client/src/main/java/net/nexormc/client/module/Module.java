package net.nexormc.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Tum modullerin tabani.
 *
 * Iki tur modul var:
 *   - HUD modulu (hud=true): ekranda bir kutusu vardir; editorde surukleyip boyutlandirilir
 *     (Keystrokes, FPS, Koordinat, Ping, Armor, Server IP, Resource Pack).
 *   - Ozellik modulu (hud=false): sadece ac/kapa (+ opsiyonel ayar) (Fullbright, Crosshair, Nametags).
 *
 * Konum (x, y) ve olcek (scale) GUI koordinatlaridir; ModuleManager bunlari nexormc.json'a yazar.
 */
public abstract class Module {

    public final String id;
    public final String name;
    public final boolean hud;

    public boolean enabled;
    public float x;
    public float y;
    public float scale = 1.0f;
    /** Modulun tek ayari (ornegin crosshair stili). Kaydedilir. */
    public int setting;

    protected Module(String id, String name, boolean hud, boolean enabledByDefault, float x, float y) {
        this.id = id;
        this.name = name;
        this.hud = hud;
        this.enabled = enabledByDefault;
        this.x = x;
        this.y = y;
    }

    // ---- Alt siniflarin doldurdugu kisim ------------------------------------------------

    /** Kutunun olcek uygulanmamis genisligi. */
    public int width(Minecraft mc) {
        return 0;
    }

    /** Kutunun olcek uygulanmamis yuksekligi. */
    public int height(Minecraft mc) {
        return 0;
    }

    /** (0,0) kutunun sol ustu olacak sekilde icerigi ciz. */
    protected void drawContent(GuiGraphics g, Minecraft mc) {}

    /** Her oyun tick'inde (saniyede 20) cagrilir. */
    public void tick(Minecraft mc) {}

    /** Ayari olan modullerde ayar butonunun yazisi; ayari yoksa null. */
    public String settingText() {
        return null;
    }

    /** Ayar butonuna basilinca ayari bir sonraki degere gecir. */
    public void cycleSetting() {}

    // ---- Ortak mantik -------------------------------------------------------------------

    /** Konum + olcegi uygulayip icerigi cizer. */
    public final void renderHud(GuiGraphics g, Minecraft mc) {
        if (!hud || !enabled) {
            return;
        }
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        drawContent(g, mc);
        g.pose().popMatrix();
    }

    /** Fare kutunun icinde mi? (olcek dahil, ekran koordinati) */
    public boolean contains(Minecraft mc, double mx, double my) {
        return mx >= x && my >= y && mx <= x + width(mc) * scale && my <= y + height(mc) * scale;
    }

    protected static void background(GuiGraphics g, int w, int h) {
        g.fill(0, 0, w, h, 0x66000000);
    }
}
