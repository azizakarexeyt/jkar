package net.nexormc.client.mixin;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ESC menusunun bulanik (blur) arka planini kaldirir; yerine cok hafif bir karartma cizer.
 * Tamamen seffaf istersen alfa degerini 0x00 yap (0x00000000).
 *
 * require = 0: hedef metot bu surumde farkliysa oyun cokmesin, sadece ozellik calismasin.
 */
@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {

    private static final int DIM = 0x30000000;

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void nexor$transparentPause(GuiGraphics graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if ((Object) this instanceof PauseScreen) {
            graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), DIM);
            ci.cancel();
        }
    }
}
